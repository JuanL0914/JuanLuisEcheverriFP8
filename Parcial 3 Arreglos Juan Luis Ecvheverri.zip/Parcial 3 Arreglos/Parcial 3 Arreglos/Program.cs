﻿namespace Parcial_3_Arreglos
{
    internal class Program
    {
        static void Main(string[] args)
        {

                int filas = Dimension("filas");
                int columnas = Dimension("columnas");

                int[,] matriz = new int[filas, columnas];

              
                for (int i = 0; i < filas; i++)
                {
                    for (int j = 0; j < columnas; j++)
                    {
                        matriz[i, j] = Valor(i, j);
                    }
                }

                Matriz(matriz, filas, columnas);

                bool continuar = true;

                while (continuar)
                {
                    Console.WriteLine("\nSeleccione una operación:");
                    Console.WriteLine("1. Sumar");
                    Console.WriteLine("2. Restar");
                    Console.WriteLine("3. Multiplicar");
                    Console.WriteLine("4. Dividir");

                    int opcion = Opcion();

                 
                    (int f1, int c1) = Posicion("primer", filas, columnas);
                    (int f2, int c2) = Posicion("segundo", filas, columnas);

                    int valor1 = matriz[f1, c1];
                    int valor2 = matriz[f2, c2];

                    if (opcion == 4)
                    {
                        while (valor2 == 0)
                        {
                            Console.WriteLine("No se puede dividir por cero. Seleccione otra posición.");
                            (f2, c2) = Posicion("segundo", filas, columnas);
                            valor2 = matriz[f2, c2];
                        }
                    }

                    double resultado = Operacion(opcion, valor1, valor2, out string operador);
                    Console.WriteLine($"\n Resultado: {valor1} {operador} {valor2} = {resultado}");

                    Console.Write("\n¿Desea realizar otra operación? (s/n): ");
                    continuar = Console.ReadLine().ToLower() == "s";

                }

                Console.WriteLine("Programa finalizado");
            }

            

            static int Dimension(string nombre)
            {
                int valor;
                do
                {
                    Console.Write($"Ingrese número de {nombre} (entre 2 y 10): ");
                } while (!int.TryParse(Console.ReadLine(), out valor) || valor < 2 || valor > 10);
                return valor;
            }

            static int Valor(int fila, int columna)
            {
                int valor;
                do
                {
                    Console.Write($"Ingrese valor para posición ({fila + 1},{columna + 1}) [-999 a 999]: ");
                } while (!int.TryParse(Console.ReadLine(), out valor) || valor <= -1000 || valor >= 1000);
                return valor;
            }

            static void Matriz(int[,] matriz, int filas, int columnas)
            {
                Console.WriteLine("\nMatriz Ingresada:");
                Console.Write("     ");
                for (int j = 0; j < columnas; j++)
                {
                    Console.Write($"[{j + 1,3}] ");
                }
                Console.WriteLine();

                for (int i = 0; i < filas; i++)
                {
                    Console.Write($"[{i + 1,3}] ");
                    for (int j = 0; j < columnas; j++)
                    {
                        Console.Write($"{matriz[i, j],5}");
                    }
                    Console.WriteLine();
                }
            }

            static int Opcion()
            {
                int opcion;
                do
                {
                    Console.Write("Opción (1-4): ");
                } while (!int.TryParse(Console.ReadLine(), out opcion) || opcion < 1 || opcion > 4);
                return opcion;
            }

            static (int, int) Posicion(string nombre, int filas, int columnas)
            {
                int f, c;
                do
                {
                    Console.Write($"Ingrese fila del {nombre} operando (1 a {filas}): ");
                } while (!int.TryParse(Console.ReadLine(), out f) || f < 1 || f > filas);

                do
                {
                    Console.Write($"Ingrese columna del {nombre} operando (1 a {columnas}): ");
                } while (!int.TryParse(Console.ReadLine(), out c) || c < 1 || c > columnas);

                return (f - 1, c - 1);
            }

            static double Operacion(int opcion, int val1, int val2, out string operador)
            {
                operador = "";
                switch (opcion)
                {
                    case 1: operador = "+"; return val1 + val2;
                    case 2: operador = "-"; return val1 - val2;
                    case 3: operador = "*"; return val1 * val2;
                    case 4: operador = "/"; return Math.Round((double)val1 / val2, 2);
                    default: return 0;
                }
            }
        }
    }


    

