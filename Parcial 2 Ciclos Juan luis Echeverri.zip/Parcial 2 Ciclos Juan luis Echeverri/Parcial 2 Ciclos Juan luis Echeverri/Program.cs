﻿namespace Parcial_2_Ciclos_Juan_luis_Echeverri
/*Un profesor tiene las calificaciones de 14 alumnos y necesita procesar la información para obtener un análisis general del curso.Las notas se encuentran en un rango de 0 a 10.
El programa debe realizar las siguientes operaciones:
Leer por teclado la nota de cada uno de los 14 estudiantes.
Calcular el promedio de todas las notas.
Identificar y mostrar cuál fue la nota mayor y la nota menor entre las ingresadas.
Contar cuántos estudiantes aprobaron la asignatura(nota mayor o igual a 6.0).
Mostrar por pantalla:
El promedio general.
La nota más alta.
La nota más baja.
La cantidad de aprobados en el curso.
*/
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Estudiantes = 14;
            int sumaNotas = 0;
            int Notas;
            int NotasMayor = 0;
            int NotasMenor = 10;
            int Contador = 0;
            int aprobados = 0;

            do
            {
                Console.WriteLine($"Ingrese la nota del estudiante {Contador + 1} (entre 0 y 10): ");
                string entrada = Console.ReadLine();

               
                if (int.TryParse(entrada, out Notas) && Notas >= 0 && Notas <= 10)
                {
                    sumaNotas += Notas;

                    if (Notas > NotasMayor)
                        NotasMayor = Notas;

                    if (Notas < NotasMenor)
                        NotasMenor = Notas;

                    if (Notas >= 6)
                        aprobados++;

                    Contador++;
                }
                else
                {
                    Console.WriteLine("Entrada inválida. Por favor ingrese un número entero entre 0 y 10.");
                }

            } while (Contador < Estudiantes);

            double promedio = (double)sumaNotas / Estudiantes;

            Console.WriteLine($"Promedio general: {promedio}");
            Console.WriteLine($"Nota más alta: {NotasMayor}");
            Console.WriteLine($"Nota más baja: {NotasMenor}");
            Console.WriteLine($"Cantidad de aprobados: {aprobados}");


        }
    }
}
